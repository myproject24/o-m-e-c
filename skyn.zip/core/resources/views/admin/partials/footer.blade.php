<footer class="main-footer">
    <div class="d-inline">{!! $setting->copyright_text !!}</div>
    <div class="float-right d-none d-sm-inline-block">
      {{ __('Version : 4.0') }}
    </div>
  </footer>
</div>
